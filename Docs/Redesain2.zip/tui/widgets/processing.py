"""
tui/widgets/processing.py — The one Processing form Translate and Judge share.

Both flows pace a job against the same three things — how many rows go in a
request, how many workers run, and the delay between requests — and both derive
sane defaults from the rate limit rather than asking cold. Before this widget
each flow had its own pacing screen and they drifted; this is the single form.

The recommendation rules (UET_UX Processing):
  * the form *aims* for the preferred rows/request (Settings, default 15);
  * it never suggests above the maximum (Settings, default 100);
  * when the rate limit only affords fewer rows safely, the lower figure is
    what shows — preferred is a target, not a floor;
  * the recommended value sits dim in the field; Enter accepts it as-is;
  * typing a different number marks a manual override, and an override that
    risks the limit shows a warning but is never blocked (power users decide).
"""

from __future__ import annotations

from dataclasses import dataclass

from textual.app import ComposeResult
from textual.containers import Vertical
from textual.widgets import Input, Label, Static

from ...data import app_prefs
from ...providers.ratelimit import RateLimitPreset
from ..theme import MUTED, WARN
from .common import LabeledInput


@dataclass
class ProcessingValues:
    """What the form resolved to, ready to drop into a draft/JobConfig."""

    rows_per_request: int
    workers: int
    request_delay: float
    manual_override: bool


def recommend(preset: RateLimitPreset, tok_per_row: int | None = None) -> tuple[int, int]:
    """
    (rows/request, workers) recommended for this preset — preferred, but capped
    by what the limit safely affords.

    The preset already knows the batch its limits sustain (`suggested_batch_size`);
    the preferred figure is only taken when the limit affords at least that many.
    Workers follow from the chosen batch, both limits considered.
    """
    preferred = app_prefs.preferred_rows_per_request()
    ceiling = app_prefs.max_rows_per_request_cap()
    affordable = max(1, int(preset.suggested_batch_size))
    # Aim for preferred, but never above what the limit sustains, nor above the cap.
    rows = min(preferred, ceiling)
    if not preset.unlimited:
        rows = min(rows, affordable)
    rows = max(1, rows)
    workers = max(1, preset.workers_for(rows, tok_per_row))
    return rows, workers


class ProcessingForm(Vertical):
    """Rows/request + Workers + a live derived-pacing line, shared by both flows."""

    def __init__(
        self,
        preset: RateLimitPreset,
        tok_per_row: int | None = None,
        rows_value: int | None = None,
        workers_value: int | None = None,
        **kwargs,
    ) -> None:
        super().__init__(**kwargs)
        self._preset = preset
        self._tok_per_row = tok_per_row
        rec_rows, rec_workers = recommend(preset, tok_per_row)
        self._rec_rows = rec_rows
        self._rec_workers = rec_workers
        # A value carried back from a previous visit is an override the user made;
        # a fresh form opens on the recommendation.
        self._init_rows = rows_value
        self._init_workers = workers_value

    def compose(self) -> ComposeResult:
        yield Label("Processing", classes="title")
        yield Label(
            "Recommended from the rate limit — press Enter to accept, or type "
            "your own. A number past the safe capacity warns but is allowed.",
            classes="hint",
        )
        yield Label("")
        self._rows = LabeledInput(
            "Rows / request",
            value=str(self._init_rows) if self._init_rows else "",
            default=str(self._rec_rows),
            hint=f"recommended {self._rec_rows}",
        )
        self._workers = LabeledInput(
            "Workers",
            value=str(self._init_workers) if self._init_workers else "",
            default=str(self._rec_workers),
            hint=f"recommended {self._rec_workers}",
        )
        yield self._rows
        yield self._workers
        yield Label("")
        yield Static("", id="processing-derived", classes="hint")
        yield Label("", id="processing-warn", classes="warn")

    def on_mount(self) -> None:
        self._rows.input.placeholder = f"recommended: {self._rec_rows}"
        self._workers.input.placeholder = f"recommended: {self._rec_workers}"
        self._update_derived()

    # ── Live derivation ──────────────────────────────────────────────────────

    def on_input_changed(self, event: Input.Changed) -> None:
        self._update_derived()

    def _typed_rows(self) -> int:
        try:
            return max(1, int(self._rows.value))
        except (ValueError, AttributeError):
            return self._rec_rows

    def _typed_workers(self) -> int:
        try:
            return max(1, int(self._workers.value))
        except (ValueError, AttributeError):
            return self._rec_workers

    def _update_derived(self) -> None:
        preset = self._preset
        rows = self._typed_rows()
        workers = self._typed_workers()
        wave = rows * workers
        derived = (
            f"Derived → {rows} rows/request · {workers} worker(s) · "
            f"wave {wave} rows · delay {preset.wave_delay}s"
        )
        if not preset.unlimited:
            derived += (
                f" · ~{preset.sustainable_rows_per_minute(rows):,} rows/min sustained"
            )
        try:
            self.query_one("#processing-derived", Static).update(derived)
        except Exception:
            return
        # Warn — never block — when the typed size outruns what the limit affords.
        warn = self.query_one("#processing-warn", Label)
        safe_workers = max(1, preset.workers_for(rows, self._tok_per_row))
        if not preset.unlimited and (rows > self._rec_rows or workers > safe_workers):
            warn.update(
                f"⚠ Above the safe capacity for this limit "
                f"(recommended {self._rec_rows} rows · {safe_workers} workers). "
                f"Allowed, but expect rate-limit backoff."
            )
        else:
            warn.update("")

    # ── Result ──────────────────────────────────────────────────────────────

    def values(self) -> ProcessingValues:
        rows = self._typed_rows()
        workers = self._typed_workers()
        override = rows != self._rec_rows or workers != self._rec_workers
        return ProcessingValues(
            rows_per_request=rows,
            workers=workers,
            request_delay=self._preset.delay_per_request,
            manual_override=override,
        )

    def focus_first(self) -> None:
        self._rows.focus_input()
